package com.goydevv.inputbridge;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import android.content.ServiceConnection;

import rikka.shizuku.Shizuku;

public final class BridgeClient {

    private static final int REQUEST_PERMISSION = 4107;
    private static final int USER_SERVICE_VERSION = 1;

    private static BridgeClient instance;

    private final Context appContext;
    private final Shizuku.UserServiceArgs serviceArgs;
    private final ServiceConnection serviceConnection;

    private IInputBridge bridge;
    private boolean initialized;

    private BridgeClient(Context context) {
        appContext = context.getApplicationContext();

        serviceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(appContext, InjectorUserService.class))
                .processNameSuffix("injector")
                .version(USER_SERVICE_VERSION)
                .tag("goy-inputbridge")
                .daemon(true)
                .debuggable(BuildConfig.DEBUG);

        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                bridge = IInputBridge.Stub.asInterface(service);
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                bridge = null;
            }
        };
    }

    public static synchronized BridgeClient get(Context context) {
        if (instance == null) {
            instance = new BridgeClient(context);
        }
        instance.ensureInitialized();
        return instance;
    }

    private void ensureInitialized() {
        if (initialized) return;
        initialized = true;
        Shizuku.addBinderReceivedListenerSticky(() -> { });
        Shizuku.addBinderDeadListener(() -> bridge = null);
    }

    public boolean isShizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable ignored) {
            return false;
        }
    }

    public boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_PERMISSION);
        } catch (Throwable ignored) {
        }
    }

    public synchronized boolean startPrivilegedService() {
        if (!isShizukuRunning()) return false;
        if (!hasPermission()) {
            requestPermission();
            return false;
        }

        try {
            Shizuku.bindUserService(serviceArgs, serviceConnection);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public synchronized void stopPrivilegedService() {
        IInputBridge b = bridge;
        bridge = null;

        if (b != null) {
            try {
                b.releaseAll();
            } catch (RemoteException ignored) {
            }
        }

        try {
            Shizuku.unbindUserService(serviceArgs, serviceConnection, true);
        } catch (Throwable ignored) {
        }
    }

    public void mouseMove(float dx, float dy, long eventTime) {
        IInputBridge b = bridge;
        if (b == null) return;
        try {
            b.mouseMove(dx, dy, eventTime);
        } catch (RemoteException e) {
            bridge = null;
        }
    }

    public void mouseButton(int button, boolean pressed, long eventTime) {
        IInputBridge b = bridge;
        if (b == null) return;
        try {
            b.mouseButton(button, pressed, eventTime);
        } catch (RemoteException e) {
            bridge = null;
        }
    }

    public void mouseScroll(float horizontal, float vertical, long eventTime) {
        IInputBridge b = bridge;
        if (b == null) return;
        try {
            b.mouseScroll(horizontal, vertical, eventTime);
        } catch (RemoteException e) {
            bridge = null;
        }
    }

    public void keyEvent(int keyCode, boolean pressed, int metaState, long eventTime) {
        IInputBridge b = bridge;
        if (b == null) return;
        try {
            b.keyEvent(keyCode, pressed, metaState, eventTime);
        } catch (RemoteException e) {
            bridge = null;
        }
    }

    public void releaseAll() {
        IInputBridge b = bridge;
        if (b == null) return;
        try {
            b.releaseAll();
        } catch (RemoteException e) {
            bridge = null;
        }
    }

    public String remoteStatus() {
        IInputBridge b = bridge;
        if (b == null) return "not connected";
        try {
            return b.getStatus();
        } catch (RemoteException e) {
            bridge = null;
            return "disconnected";
        }
    }

    public int remoteUid() {
        IInputBridge b = bridge;
        if (b == null) return -1;
        try {
            return b.getUid();
        } catch (RemoteException e) {
            bridge = null;
            return -1;
        }
    }
}

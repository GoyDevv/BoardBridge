# goy input bridge site

static companion page for vercel.

use inputbridge/site as the root directory when deploying from the full repository.
